<?php
include 'common.php';
function check_if_added_to_cart($item_id){
    $user_id=$_SESSION['user_id'];
    $select_query="SELECT * FROM users_products WHERE item_id='$item_id' AND user_id='$user_id' AND status='Added to cart'";
    $select_result=mysqli_query($select_query);
    if(mysqli_num_rows($select_result)>1){
        return 1;
    }
 else{
        return 0;   
 }
}    


?>


