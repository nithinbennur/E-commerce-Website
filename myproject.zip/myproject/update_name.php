<?php
$con=  mysqli_connect("localhost","root","root","lifestylestore") or die(mysqli_error($con));
session_start();
$name=$_GET['name'];
$user_id=$_SESSION['id'];
$update_query="UPDATE users SET name='$name' WHERE id='$user_id'";
$update_query_result=  mysqli_query($con, $update_query) or die(mysqli_errno($con));
echo 'Name Updated';
?>

