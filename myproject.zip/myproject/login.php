<?php
require 'includes/common.php';
?>
<html lang="en"> 
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | Life Style Store</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Jquery Library -->
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Javascript File -->
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
        </script>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link href="css/bootstrap.css" rel="stylesheet">
</head>
<body>
<?php
include 'includes/header.php';
?>
    <div id="content">
        <div class="container-fluid decor_bg" id="login-panel">
            <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h4>LOGIN</h4>
                        </div>
                        <div class="panel-body">
                            <p class="text-warning"><i>Login to make purchase</i></p>
                            <form role="form" action="login_script.php" method="POST">
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Email" required="true" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
                                    <div><?php echo $_GET['email_error'];?></div>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="Password" name="password" required="true" pattern=".{6,}">
                                    <div><?php echo $_GET['password_error'];?></div>
                                 </div>
                                 <button type="submit" name="submit" class="btn btn-primary">Login</button><br><br>
                                    </form><br/>
                        </div>
                        <div class="panel-footer"><p>Don't have an account? <a href="signup.php">Register</a></p></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
        include 'includes/footer.php';
        ?>
</body>
</html>

