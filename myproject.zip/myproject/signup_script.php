<?php
include 'includes/common.php';
$con=  mysqli_connect("localhost","root","root","lifestylestore") or die(mysqli_errno($con));
session_start();
$email=  mysqli_real_escape_string($con,$_POST['email']);
$name=  mysqli_real_escape_string($name,$_POST['name']);
$password=  mysqli_real_escape_string($con,$_POST['password']);
$contact=  $_POST['contact'];
$city=  mysqli_real_escape_string($con,$_POST['city']);
$address=  mysqli_real_escape_string($con,$_POST['address']);
$query_insert="insert into users (email,name,password,contact,city,address)values('$email','$name','$password','$contact','$city','$address')";
$user_reg=  mysqli_query($con, $query_insert) or die(mysqli_errno($con));
echo 'User Registered Successfully';
$_SESSION['email']=$email;
$_SESSION['id']=  mysqli_insert_id($con);
?>
<?php
header('location:products.php');
?>

