<?php
require 'includes/common.php';
if(!isset($_SESSION['email'])){
    header('location:index.php');
}
$password=md5($_POST['oldpassword']);
if(strlen($password)<6){
    header('location:login.php?old_password_error=enter correct password');
}
$password=  md5($_POST['password']);
$password1=  md5($_POST['password1']);
if(strlen($password)<6 && strlen($password1)<6)
{
    echo 'error';
}
$select_query="SELECT password FROM users";
$select_result=  mysqli_query($con, $select_query);
if($password==$select_result){
    header('location:ugdate_name.php'); 
}
 else {
    header('location:settings.php');
    echo 'Error in Password';
}
?>

