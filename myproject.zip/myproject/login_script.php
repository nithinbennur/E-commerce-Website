<?php
require 'includes/common.php';
$email=$_POST['email'];
$regex_email="/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";
if (!preg_match($regex_email, $email)){
    header('location:login.php?email_error=enter correct email');
}
$password=md5($_POST['password']);
if (strlen($password)<6){
    header('location:login.php?password_error=enter correct password');
}
$email=  mysqli_real_escape_string($con,$_POST['email']);
$password=  mysqli_real_escape_string($con,$_POST['password']);
$login_script_query="select id,email from users";
if (mysqli_num_rows($login_script_query)==0){
    echo 'There is no user present';
}
 else {
    mysqli_fetch_array($login_script_query);
    header('location:products.php');
}
$email_error="";
$email_error=$_SESSION['email_error'];
$user_id=$_POST['id'];
?>